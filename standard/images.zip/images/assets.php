<!DOCTYPE html>
<html>
<head>
<title>Aplicativo</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="author" content="" />
<meta name="copyright" content="&copy;" />
<meta name="robot" content="all" />

<link rel="stylesheet"
	href="//www.santafe.gov.ar/assets/standard/css/normalize.css"
	type="text/css" />
<link rel="stylesheet"
	href="//www.santafe.gov.ar/assets/standard/css/1140.css"
	type="text/css" />
<link rel="stylesheet"
	href="//www.santafe.gov.ar/assets/jquery-ui/jquery-ui-1.10.3/css/gobierno/jquery-ui-1.10.3.custom.css"
	type="text/css" />
<link rel="stylesheet"
	href="//www.santafe.gov.ar/assets/bootstrap/bootstrap-3.0.2-dist/tables-bootstrap/css/bootstrap.min.css"
	type="text/css" />
<link rel="stylesheet"
	href="//www.santafe.gov.ar/assets/standard/css/pagination/html5-pagination.css"
	type="text/css" />

<!--script type="text/javascript" src="js/css3-mediaqueries.js"></script-->

<link rel="stylesheet"
	href="//www.santafe.gov.ar/assets/standard/css/styles.css"
	type="text/css" />

<!-- 1140px Grid styles for IE -->
<!--[if lte IE 9]><link rel="stylesheet" href="//www.santafe.gov.ar/assets/standard/css/ie.css" type="text/css" media="screen" /><![endif]-->

<!--[if gte IE 9]>
                <style type="text/css">
                        .gradient {
                                filter: none;
                        }
                </style>
                <![endif]-->
<style>
#dialog-message-info,.submenu {
	display: none;
}
</style>
</head>

<body id="top">
	<div class="container">
		<div class="row">
			<div class="twelvecol date">
				<ul id="icons" class="ui-widget ui-helper-clearfix">
					<li>

						<div class="icons_fila">
							<span class="ui-icon ui-icon-contact"> </span>
						</div>
						<div class="icons_fila">
							<a href="//www.santafe.gov.ar/index.php/web/guia/contactenos"
								target="_blank" title="Contacto">Contacto</a>
						</div>

					</li>
					<!--li>

						<div class="icons_fila">
							<span class="ui-icon ui-icon-eject"> </span>
						</div>

						<div class="icons_fila">
							<a title="Salir del sistema..." href="#">Salir</a>
						</div>


					</li-->
					<!-- li>
						<div class="icons_fila">
							<span class="ui-icon ui-icon-person"> </span>
						</div>
						<div class="icons_fila">Usuario</div>
					</li-->
				</ul>

				<ul class="icons_left ui-widget ui-helper-clearfix">
					<li>
						<div class="icons_fila">
							<span class="ui-icon ui-icon-calendar calendario_fecha_general">
							</span>
						</div>
						<div class="icons_fila">16/04/2014</div>
					</li>
				</ul>

			</div>

		</div>

		<div class="row">
			<div class="twelvecol head_aplicativo">


				<div class="div_left">
					<img alt="Gobierno de Santa Fe"
						src="//www.santafe.gov.ar/assets/standard/images/logo-stafeavanza.jpg">
				</div>
				<h1 class="div_right">Estructura de assets</h1>


			</div>
		</div>

		<div class="row">
			<div class="twelvecol dependence-name">
				<p>Ministerio de Gobierno y Reforma del Estado - Secretaría de
					Tecnologías para la Gestión</p>
			</div>
		</div>

		<div class="row">
			<div id="toolbars" class="twelvecol tool-bars">
				<ul class="ui-widget ui-helper-clearfix" id="icons">

					<li id="ver_ayuda" title="Clic para ver ayuda"
						class="ui-state-default ui-corner-all"><span
						class="ui-icon ui-icon-info"></span></li>
					<li title="" class="ui-state-default ui-corner-all"><span
						class="ui-icon ui-icon-carat-1-n"></span></li>
					<li title="" class="ui-state-default ui-corner-all"><span
						class="ui-icon ui-icon-carat-1-ne"></span></li>

				</ul>
				<div class="clear"></div>
			</div>
		</div>

		<div>
			<div class="header_menu">
				<!-- a id="logo" href="#">Logo</a-->
				<div id="menu">
					<a href="#" id="nav-mobile" class="nav-mobile"> </a>
					<ul class="">

						<!-- li><a href="#" class="opcion">Opción</a>

							<div>
								<ul class="submenu">
									<li><a class="sub-menu" target="_top" href="#">Listado</a></li>
								</ul>
							</div></li>
						<li><a href="#" class="opcion">Opción 1</a>

							<div>
								<ul class="submenu">

									<li><a class="sub-menu" target="_top" href="#">Listado</a></li>
									<li><a class="sub-menu" target="_top" href="#">Crear</a></li>

								</ul>

							</div></li>
						<li><a href="#" class="opcion">Opción 2</a>
							<div>
								<ul class="submenu">

									<li><a class="sub-menu" target="_top" href="#">Listado</a></li>
									<li><a class="sub-menu" target="_top" href="#">Crear</a></li>

								</ul>

							</div></li-->

					</ul>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="twelvecol ruta-name">

				<div class="div_left">
					<a href="#">Inicio</a>
				</div>
				<span class="div_left ui-icon ui-icon-arrow-1-e"> </span>

				<div class="div_left">Listado</div>
			</div>
		</div>

		<div class="row form">
			<form>
				<h3>Listado de assets de imágenes</h3>
				<div class="row">
					<div class="elevencol">
    				<?php

        function listar_directorios_ruta($ruta)
        {
            global $dominio;
            if (is_dir($ruta)) {
                if ($dh = opendir($ruta)) {
                    while (($file = readdir($dh)) !== false) {
                        $ext = explode(".", $file); // separa la variable
                        $num = count($ext) - 1;
                        $extension = strtoupper($ext[$num]);
                        
                        
                          if (($extension == strtoupper("jpg")) or ($extension == strtoupper("gif")) or ($extension == strtoupper("png")) or ($extension == strtoupper("ico"))) {
							echo '<div class="row">' . '<div class="row"><div class="elevencol">';
							echo '<fieldset style="margin:5px;" class="recuadro"><legend>' . $file . '</legend>';
							echo '<div style="margin-left:5px;"><img border="0" src="' . $ruta . $file . '" ></div>';
							echo '</fieldset></div></div></div>';
							
                          }
                         
                        /*
                        if (($extension == strtoupper("css")) or ($extension == strtoupper("js"))) {
                            
                            echo '<div class="row">' . '<div class="row"><div class="elevencol"> <a href="' . $ruta . $file . '" >' . $dominio . substr($ruta, 1) . $file . '</a></div></div></div>';
                        }
						*/
                        
                        if (is_dir($ruta . $file) && $file != "." && $file != "..") {
                            /*
                             * echo '<div class="row form">
                             * <form>
                             * <h3>' . $dominio . $ruta . $file . '</h3>
                             * <div class="row">
                             * <div class="elevencol"></div></form></div></div>';
                             */
                            listar_directorios_ruta($ruta . $file . "/");
                        }
                    }
                    closedir($dh);
                }
            } else
                echo "<br>No es ruta valida";
        }
        
        $dominio = "//www.santafe.gov.ar/assets/standard/images";
        listar_directorios_ruta("./");
        ?>
				</div>
				</div>
			</form>
		</div>


		<div
			style="float: right; margin-top: 5px; margin-right: 5px; color: white;">
			<a href="#top" class="link_white"> Ir arriba </a>
		</div>

		<div class="row">
			<div class="twelvecol footer">

				<div style="clear: both">

					<div class="footer_datos">
						<p>GOBIERNO DE SANTA FE</p>
						<p>3 de Febrero 2649 (S3000DEE) Santa Fe</p>
						<p>54 342 4506600 | 4506700 | 4506800</p>

					</div>

				</div>

				<!--p>
        <span> &copy; 2013 - Todos los derechos reservados. Créditos | Términos y condiciones</span>
        </p-->
			</div>
		</div>

	</div>

	<div class="content_dialog" id="dialog-message-info" title="Ayuda">

		<p>Ayuda general...</p>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting
			industry. Lorem Ipsum has been the industry's standard dummy text
			ever since the 1500s, when an unknown printer took a galley of type
			and scrambled it to make a type specimen book. It has survived not
			only five centuries, but also the leap into electronic typesetting,
			remaining essentially unchanged. It was popularised in the 1960s with
			the release of Letraset sheets containing Lorem Ipsum passages, and
			more recently with desktop publishing software like Aldus PageMaker
			including versions of Lorem Ipsum.</p>

	</div>


	<!-- script
                src="//www.santafe.gov.ar/assets/jquery-ui/jquery-ui-1.10.3/js/jquery-1.10.2.min.js"></script-->

	<script src="//www.santafe.gov.ar/assets/jquery/jquery-1.11.1.min.js"></script>

	<script
		src="//www.santafe.gov.ar/assets/jquery-ui/jquery-ui-1.10.3/js/jquery-ui.min.js"></script>
	<script
		src="//www.santafe.gov.ar/assets/jquery-ui/jquery-ui-1.10.3/js/jquery.ui.datepicker-es.js"></script>
	<script
		src="//www.santafe.gov.ar/assets/jquery/jquery.ui.touch-punch.min.js"></script>

	<script src="//www.santafe.gov.ar/assets/standard/js/match-media.js"></script>

	<script src="//www.santafe.gov.ar/assets/standard/js/interface.js"></script>

	<script>
            $(document).ready(function() {
                $.ajaxSetup({
                    timeout: '60000',
                    global: true
                });

                $("#ver_ayuda").click(function() {

                    $("#dialog-message-info").dialog('open');

                });

                $("#dialog-message-info").dialog({
                    autoOpen: false,
                    width: 'auto', // overcomes width:'auto' and maxWidth bug
                    height: 'auto',
                    modal: true,
                    fluid: true, //new option
                    resizable: true,
                    create: function(event, ui) {
                        // Set maxWidth
                        $(this).css("max-width", "660px");
                    },
                    open: function() {
                        //fluidDialog();
                    },
                    buttons: {
                        Aceptar: function() {
                            $(this).dialog("close");
                        }
                    },
                    close: function() {
                    }
                });

            });
        </script>
</body>
</html>